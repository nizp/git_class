import React,{Component} from 'react';
export class Li extends Component{
  render(){
    return (
      <li>
        <h2>{this.props.h}</h2>
        <span>{this.props.s}</span>
        <span>{this.props.tq}</span>
      </li>
    )
  }
}

