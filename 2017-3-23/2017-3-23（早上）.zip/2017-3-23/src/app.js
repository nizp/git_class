import {Li} from './comm/li.js';
import React,{Component} from 'react';
import ReactDOM from 'react-dom';
/*
  在react中，如果数据为父组件流动来的，那么不操作，只接收，只渲染。
  es6语法：设置状态
    this.state = {}
  获取状态:
    this.state
  更改状态:
    this.setState({})
    
  事件：
      onClick,
      onMouseover = {this.props.fn}
      onMouseoout = {this.fn}
      
  解构赋值，如果是对象那么同样为赋址。
  let {arr} = this.state;
  [] = []
  [].push({})
  setState() //只要调用setState就会重新渲染页面
 */
class App extends Component{
  constructor(props){
    super(props);
    this.state = {
      arr:this.props.str,
      num:0
    }
    this.clickFn = this.clickFn.bind(this);
  }
  
  clickFn(){
    
    //先获取到状态中的arr和num
    let {arr,num:newNum} = this.state;
    
    let newArr = Object.assign([],arr);
    
    newNum++;
    
    let data = {
      h:'妙味'+newNum,
      s:'miaov',
      tq:'大太阳'
    }
    // this.state.arr 已经被改变
    newArr.push(data);
    
    //设置状态。
    this.setState({
        arr:newArr,
        num:newNum
    })
  }
  
  render(){
    let arr = this.state.arr;//this.props.str;
    
    let list = null;
    
    list = arr.map((ele,i)=>{
      let datas = {
        h:ele.h,
        s:ele.s,
        key:i+(new Date().getTime()),
        tq:ele.tq
      }
      return <Li {...datas}/>
    });
    
    return (
      <div>
        <input
          type="button"
          value="点击创建"
          onClick={this.clickFn}
        />
        <ul>
          {list}
        </ul>
      </div>
    )
  }
}

let data = {
  str:[{h:'好好',s:'haohao',tq:'(晴)'},{h:'学习',s:'xuexi',tq:'(霾)'}]
}
ReactDOM.render(
  <App {...data}/>,
  document.getElementById('box')
)
 
