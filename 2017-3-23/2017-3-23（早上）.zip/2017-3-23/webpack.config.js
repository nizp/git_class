const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const html = new HtmlWebpackPlugin({
  filename: '../index.html',
  template: 'index.html'
})
module.exports = {
  entry:{
    app:"./src/app.js"
  },
  output:{
    path:path.resolve(__dirname,'build/src'),
    filename:"app.js"
  },
  module:{
    rules:[
      {
          test: /\.js$/,
          use: [
          {
            loader:'babel-loader',
            options:{
              presets:["latest","react"]
            }
          }],
          exclude: [path.resolve(__dirname, 'node_modules')]
      }
    ]
  },
  plugins:[
    html
  ]
  
}